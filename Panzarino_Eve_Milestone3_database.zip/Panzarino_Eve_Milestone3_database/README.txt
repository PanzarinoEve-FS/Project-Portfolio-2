LGBTQIA+ Safety Index - database import
Eve Panzarino - Milestone 3

The app reads from a local MongoDB database named "safety-app".
This folder holds every collection it needs, one JSON array per file.

TO IMPORT (macOS / Linux):

    ./import.sh

Or one collection at a time:

    mongoimport --db safety-app --collection surgeons --file surgeons.json --jsonArray --drop

On Windows, run the same mongoimport line for each .json file in this folder.

WHAT YOU GET

    surgeons          1,596   trans surgeons and surgery centers
    cei                 112   HRC Corporate Equality Index scores
    reviews              69   LGBTQIA+ reviews of named businesses
    surgeonreviews        1   a community rating on a directory entry
    zipscores           145   Business Safety Scores per ZIP (Heatmap)
    zctas               145   Census ZIP boundary shapes for those ZIPs
    sweepbusinesses   9,809   cached OpenStreetMap business sweep

The "users" collection is deliberately not included - it holds password
hashes. Register an account in the app to try login and favorites.

RUNNING THE APP

    cd server && npm install
    cp .env.example .env        # set JWT_SECRET to any 32+ character string
    npm start                   # API on http://localhost:5050

    cd client && npm install
    npm run dev                 # site on http://localhost:5173

If you would rather the app load the data itself, "npm run seed" in the
server folder does the same thing from the JSON already in the repo.
